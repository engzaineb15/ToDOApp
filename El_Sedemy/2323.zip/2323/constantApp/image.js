
const photo1 = require("../assestApp/photo111.jpg")

const photo2 = require("../assestApp/photo2.jpg")
const photo3 = require("../assestApp/photo3.jpg")
const photo4 = require("../assestApp/photo4.jpg")
const photo5 = require("../assestApp/photo5.jpg")
const photo6 = require("../assestApp/photo6.jpg")
const photo7 = require("../assestApp/photo7.jpg")
const photo8 = require("../assestApp/photo8.jpg")
const photo9 = require("../assestApp/photo9.jpg")
const photo10 = require("../assestApp/photo11.jpg")
const photo11 = require("../assestApp/photo10.jpg")

const photo12 = require("../assestApp/ph.png")
const photo13 = require("../assestApp/pp.png")
const photo14 = require("../assestApp/ph4.png")
const photo15 = require("../assestApp/ph3.png")
const photo16 = require("../assestApp/ph8.png")

const photo17 = require("../assestApp/ph5.png")
const photo18 = require("../assestApp/ph6.png")
const photo19 = require("../assestApp/ph7.png")
const photo20 = require("../assestApp/ph10.png")
const photo21 = require("../assestApp/ph9.png")



const photo22= require("../assestApp/cow.png")
const photo23 = require("../assestApp/mazza.png")





export {photo1,photo2,photo3,photo4,photo5,photo6,photo7,photo8,photo9,photo10,photo11,photo12,photo13,photo14,photo15,photo16,photo17,photo18,photo19,photo20,photo21,photo22,photo23};